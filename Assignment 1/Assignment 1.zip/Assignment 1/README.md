Forest Fires Simulation

Description: This is a simulation for forest fire. Using main.c to execute the program.